### Minutes
# Meeting started 5pm
# all present

# Sibi

Sibi modularised code and worked on error checking

# Sam

Nothing to report

# James

Nothing to report

# Josh

Worked on retriever for a few hours
Has come to the realisation that we don't need one and is happy to delete all his code

# Camilo

emailed and contacted mark about sheets
added sheets to github
researched techniques for analyising excell documents

# Tasks For Sprint two

- Demonstrate project to Mark and record minutes of that demonstration
- write down thoughts on how project is tracking
- User Stories

Sprint 2 due week 8 Wednesday

# Demonstrate to mark earlier in the week

Ask Demonstrate earlier Wednesday to give us time to do the sprint 2





